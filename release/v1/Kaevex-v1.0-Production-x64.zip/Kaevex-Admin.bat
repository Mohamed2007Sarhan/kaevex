@echo off
title Kaevex Security Platform v1.0 - Admin Console
color 0B
cd /d "%~dp0"

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Requesting administrative privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo ========================================================================
echo   KAEVEX SECURITY PLATFORM v1.0 - SOC ENTERPRISE (ADMIN)
echo ========================================================================
echo.
echo [*] Launching Kaevex SOC Enterprise Dashboard...
start "" "%~dp0dist\Kaevex-GUI.exe"
echo [OK] Kaevex running in background.
echo.
echo [*] Press any key to open CLI management shell, or close this window.
pause >nul
"%~dp0dist\kaevex-cli.exe"
